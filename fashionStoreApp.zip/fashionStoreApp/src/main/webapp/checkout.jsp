<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:40px;
        }

        .checkout-box{
            width:500px;
            margin:auto;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .checkout-box h2{
            margin-bottom:30px;
            text-align:center;
        }

        .checkout-box input,
        .checkout-box textarea{
            width:100%;
            padding:12px;
            margin-bottom:20px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .checkout-box button{
            width:100%;
            padding:14px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;
        }

    </style>

</head>

<body>

<div class="checkout-box">

    <h2>Checkout</h2>

   <form action="success.jsp" method="post">

        <input type="text" placeholder="Full Name">

        <input type="email" placeholder="Email Address">

        <input type="text" placeholder="Phone Number">

        <textarea rows="4" placeholder="Delivery Address"></textarea>

        <button type="submit">Place Order</button>

    </form>

</div>

</body>
</html>