<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Logout</title>

    <style>
        body{
            font-family:Arial;
            background:#f5f5f5;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
        }

        .logout-box{
            background:white;
            padding:40px;
            border-radius:20px;
            text-align:center;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .logout-box h2{
            color:green;
            margin-bottom:20px;
        }

        .logout-box a{
            background:blue;
            color:white;
            padding:12px 25px;
            border-radius:25px;
            text-decoration:none;
        }
    </style>
</head>

<body>

<div class="logout-box">
    <h2>Logged Out Successfully</h2>
    <a href="login.jsp">Login Again</a>
</div>

</body>
</html>