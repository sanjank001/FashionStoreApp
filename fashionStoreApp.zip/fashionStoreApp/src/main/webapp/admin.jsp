<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            display:flex;
            background:#f5f5f5;
        }

        .sidebar{
            width:250px;
            height:100vh;
            background:#111827;
            color:white;
            padding:30px;
        }

        .sidebar h2{
            margin-bottom:40px;
        }

        .sidebar ul{
            list-style:none;
        }

        .sidebar ul li{
            margin-bottom:25px;
        }

        .sidebar ul li a{
            color:white;
            text-decoration:none;
            font-size:18px;
        }

        .main-content{
            flex:1;
            padding:40px;
        }

        .cards{
            display:flex;
            gap:20px;
            margin-top:30px;
        }

        .card{
            width:250px;
            background:white;
            padding:30px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .card h3{
            margin-bottom:15px;
        }

        .card p{
            font-size:30px;
            color:blue;
            font-weight:bold;
        }

    </style>

</head>

<body>

<div class="sidebar">

    <h2>Admin Panel</h2>

    <ul>
        <li><a href="#">Dashboard</a></li>
        <li><a href="#">Products</a></li>
        <li><a href="#">Orders</a></li>
        <li><a href="#">Users</a></li>
        <li><a href="#">Logout</a></li>
    </ul>

</div>

<div class="main-content">

    <h1>Dashboard</h1>

    <div class="cards">

        <div class="card">
            <h3>Total Products</h3>
            <p>120</p>
        </div>

        <div class="card">
            <h3>Total Orders</h3>
            <p>85</p>
        </div>

        <div class="card">
            <h3>Total Users</h3>
            <p>240</p>
        </div>

    </div>

</div>

</body>
</html>