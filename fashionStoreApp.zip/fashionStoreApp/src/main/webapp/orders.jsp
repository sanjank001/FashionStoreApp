<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Orders</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:40px;
        }

        .orders-box{
            width:85%;
            margin:auto;
            background:white;
            padding:30px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .orders-box h2{
            margin-bottom:25px;
        }

        table{
            width:100%;
            border-collapse:collapse;
        }

        th, td{
            padding:15px;
            border-bottom:1px solid #ddd;
            text-align:center;
        }

        th{
            background:#f0f0f0;
        }

        .status{
            color:green;
            font-weight:bold;
        }

    </style>

</head>

<body>

<div class="orders-box">

    <h2>My Orders</h2>

    <table>

        <tr>
            <th>Order ID</th>
            <th>Product</th>
            <th>Price</th>
            <th>Status</th>
        </tr>

        <tr>
            <td>#1001</td>
            <td>Black Casual Shirt</td>
            <td>&#8377;999</td>
            <td class="status">Delivered</td>
        </tr>

        <tr>
            <td>#1002</td>
            <td>Blue Slim Fit Jeans</td>
            <td>&#8377;1499</td>
            <td class="status">Shipped</td>
        </tr>

    </table>

</div>

</body>
</html>