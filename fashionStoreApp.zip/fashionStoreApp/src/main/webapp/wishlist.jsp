<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Wishlist</title>
    <link rel="stylesheet" href="css/style.css">

    <style>

        .wishlist-title{
            margin-bottom:30px;
            font-size:35px;
        }

    </style>

</head>

<body>

<nav class="navbar">
    <h1>Fashion Store</h1>

    <ul>
        <li><a href="index.jsp">Home</a></li>
        <li><a href="products.jsp">Products</a></li>
        <li><a href="cart.jsp">Cart</a></li>
        <li><a href="wishlist.jsp">Wishlist</a></li>
    </ul>
</nav>

<section class="products">

    <h2 class="wishlist-title">My Wishlist</h2>

    <div class="product-container">

        <div class="product-card">
            <img src="https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400">

            <h3>Black Casual Shirt</h3>

            <p>&#8377;999</p>

            <button>Add to Cart</button>
        </div>

        <div class="product-card">
            <img src="https://images.unsplash.com/photo-1542272604-787c3835535d?w=400">

            <h3>Blue Slim Fit Jeans</h3>

            <p>&#8377;1499</p>

            <button>Add to Cart</button>
        </div>

    </div>

</section>

</body>
</html>
