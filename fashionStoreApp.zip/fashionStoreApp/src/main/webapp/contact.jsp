<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:50px;
        }

        .contact-box{
            width:500px;
            margin:auto;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .contact-box h2{
            text-align:center;
            margin-bottom:30px;
        }

        .contact-box input,
        .contact-box textarea{
            width:100%;
            padding:12px;
            margin-bottom:20px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .contact-box button{
            width:100%;
            padding:14px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            cursor:pointer;
            font-size:16px;
        }

    </style>

</head>

<body>

<div class="contact-box">

    <h2>Contact Us</h2>

    <form>

        <input type="text" placeholder="Enter Name">

        <input type="email" placeholder="Enter Email">

        <textarea rows="5" placeholder="Enter Message"></textarea>

        <button>Send Message</button>

    </form>

</div>

</body>
</html>