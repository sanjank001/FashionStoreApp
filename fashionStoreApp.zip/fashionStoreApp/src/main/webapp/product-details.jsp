<%@ page import="com.fashionstore.model.Product" %>

<%
Product p = (Product) request.getAttribute("product");

String name = "";
String price = "";
String image = "";
String description = "";

if (p != null) {
    name = p.getName();
    price = String.valueOf(p.getPrice());
    image = p.getImage_url();
    description = p.getDescription();
} else {
    name = request.getParameter("name");
    price = request.getParameter("price");
    image = request.getParameter("image");
    description = "Premium quality product with modern design and comfortable fit.";
}
%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Product Details</title>

<link rel="stylesheet"
href="<%= request.getContextPath() %>/css/style.css">

</head>

<body>

<div class="container">

<nav class="navbar">

<h1>Fashion Store</h1>

<ul>
<li><a href="index.jsp">Home</a></li>
<li><a href="products">Products</a></li>
<li><a href="cart.jsp">Cart</a></li>
</ul>

</nav>

<div class="product-details">

<div class="details-image">

<img src="<%= image %>" alt="product">

</div>

<div class="details-info">

<h2><%= name %></h2>

<h3>&#8377;<%= price %></h3>

<p>
<%= description %>
</p>

<p><b>Brand:</b></p>
<p>Fashion Store</p>

<p><b>Color:</b></p>
<p>Available Color</p>

<p><b>Available Sizes:</b></p>

<div class="sizes">
<span>6</span>
<span>7</span>
<span>8</span>
<span>9</span>
<span>10</span>
</div>
<form action="add-to-cart" method="post">

<input type="hidden" name="id"
value="<%= request.getParameter("id") %>">

<input type="hidden" name="name"
value="<%= name %>">

<input type="hidden" name="price"
value="<%= price %>">

<input type="hidden" name="image"
value="<%= image %>">

<button type="submit" class="add-cart-btn">
Add to Cart
</button>

</form>
</div>

</div>

</div>

</body>
</html>