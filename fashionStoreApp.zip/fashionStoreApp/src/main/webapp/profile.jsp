<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>User Profile</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:50px;
        }

        .profile-box{
            width:500px;
            margin:auto;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .profile-box h2{
            text-align:center;
            margin-bottom:30px;
        }

        .profile-item{
            margin-bottom:20px;
        }

        .profile-item label{
            font-weight:bold;
            display:block;
            margin-bottom:8px;
        }

        .profile-item input{
            width:100%;
            padding:12px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .profile-box button{
            width:100%;
            padding:14px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            cursor:pointer;
            font-size:16px;
            margin-top:20px;
        }

    </style>

</head>

<body>

<div class="profile-box">

    <h2>User Profile</h2>

    <div class="profile-item">
        <label>Full Name</label>
        <input type="text" value="John Doe">
    </div>

    <div class="profile-item">
        <label>Email</label>
        <input type="email" value="john@example.com">
    </div>

    <div class="profile-item">
        <label>Phone</label>
        <input type="text" value="9876543210">
    </div>

    <div class="profile-item">
        <label>Address</label>
        <input type="text" value="New York">
    </div>

    <button>Update Profile</button>

</div>

</body>
</html>