<%@ page import="java.util.List" %>
<%@ page import="com.fashionstore.model.Product" %>
<%@ page import="com.fashionstore.dao.ProductDAO" %>

<%
ProductDAO dao = new ProductDAO();
List<Product> products = dao.getAllProducts();
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Fashion Store</title>

<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>

<body>

<div class="container">

<nav class="navbar">
    <h1>Fashion Store</h1>
<form action="products" method="get" class="search-form">

<input type="text"
name="search"
placeholder="Search products...">

<button type="submit">
Search
</button>

</form>

    <ul>
        <li><a href="index.jsp">Home</a></li>
        <li><a href="products">Products</a></li>
        <li><a href="cart.jsp">Cart</a></li>
        <li><a href="login.jsp">Login</a></li>
    </ul>
</nav>

<section class="hero">
    <div>
        <h2>Discover Your Style</h2>
        <p>Explore the latest fashion trends for men and women. Find your perfect outfit today.</p>
<a href="products">
<button class="shop-btn">
    Shop Now
    <span>&#8594;</span>
</button>
    </div>

    <img src="https://images.unsplash.com/photo-1496747611176-843222e1e57c" alt="fashion">
</section>
<div class="auto-slider">

<div class="slider-track">

<div class="slide-card">
<img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff">
<h3>Sports Shoes</h3>
<p>&#8377;2499</p>
</div>

<div class="slide-card">
<img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30">
<h3>Smart Watch</h3>
<p>&#8377;3999</p>
</div>

<div class="slide-card">
<img src="https://images.unsplash.com/photo-1584917865442-de89df76afd3">
<h3>Women Handbag</h3>
<p>&#8377;1899</p>
</div>

<div class="slide-card">
<img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e">
<h3>Bluetooth Headphones</h3>
<p>&#8377;2999</p>
</div>

<div class="slide-card">
<img src="https://images.unsplash.com/photo-1512436991641-6745cdb1723f">
<h3>Fashion Jacket</h3>
<p>&#8377;3499</p>
</div>

</div>

</div>
</div>
<section class="products">

<div class="product-header">
    <h2>Latest Products</h2>
    <a href="products">View All</a>
</div>

<div class="product-container">

<%
int count = 0;
for(Product p : products){
    if(count == 4) break;
%>

<div class="product-card">

<img src="<%= p.getImage_url() %>" alt="product">

<h3><%= p.getName() %></h3>

<p>&#8377;<%= p.getPrice() %></p>

<form action="add-to-cart" method="post">
    <input type="hidden" name="id" value="<%= p.getId() %>">
    <input type="hidden" name="name" value="<%= p.getName() %>">
    <input type="hidden" name="price" value="<%= p.getPrice() %>">
    <input type="hidden" name="image" value="<%= p.getImage_url() %>">

    <button type="submit">Add to Cart</button>
</form>

</div>

<%
count++;
}
%>

</div>

</section>


<footer class="footer">

<div>
    <h3>Fashion Store</h3>
    <p>Your one-stop destination for fashion, electronics and lifestyle.</p>
</div>

<div>
    <h3>Quick Links</h3>
    <p><a href="index.jsp">Home</a></p>
    <p><a href="products">Products</a></p>
    <p><a href="cart.jsp">Cart</a></p>
</div>

<div>
    <h3>Contact</h3>
    <p>Email: support@fashionstore.com</p>
    <p>Phone: +91 9876543210</p>
</div>

</footer>

</div>

</body>
</html>