<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order Success</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            background:#f5f5f5;
        }

        .success-box{
            width:450px;
            background:white;
            padding:50px;
            text-align:center;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .success-box h1{
            color:green;
            margin-bottom:20px;
        }

        .success-box p{
            font-size:18px;
            margin-bottom:30px;
        }

        .success-box a{
            text-decoration:none;
            background:blue;
            color:white;
            padding:12px 25px;
            border-radius:25px;
        }

    </style>

</head>

<body>

<div class="success-box">

    <h1>Order Placed Successfully!</h1>

    <p>
        Thank you for shopping with Fashion Store.
    </p>

    <a href="index.jsp">Continue Shopping</a>

</div>

</body>
</html>