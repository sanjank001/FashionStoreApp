<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Search Products</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:40px;
        }

        .search-box{
            width:80%;
            margin:auto;
            background:white;
            padding:30px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .search-box h2{
            margin-bottom:20px;
        }

        .search-bar{
            display:flex;
            gap:10px;
            margin-bottom:30px;
        }

        .search-bar input{
            flex:1;
            padding:12px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .search-bar button{
            padding:12px 25px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            cursor:pointer;
        }

        .result-card{
            background:#fafafa;
            padding:20px;
            border-radius:15px;
            margin-bottom:20px;
        }

        .result-card h3{
            margin-bottom:10px;
        }

        .price{
            color:green;
            font-weight:bold;
        }

    </style>

</head>

<body>

<div class="search-box">

    <h2>Search Products</h2>

    <div class="search-bar">
        <input type="text" placeholder="Search fashion products...">
        <button>Search</button>
    </div>

    <div class="result-card">
        <h3>Black Casual Shirt</h3>
        <p class="price">&#8377;999</p>
    </div>

    <div class="result-card">
        <h3>Blue Slim Fit Jeans</h3>
        <p class="price">&#8377;1499</p>
    </div>

</div>

</body>
</html>
