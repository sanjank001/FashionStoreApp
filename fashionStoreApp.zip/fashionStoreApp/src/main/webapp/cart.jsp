<%@ page import="java.util.List" %>
<%@ page import="com.fashionstore.model.Product" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>

<body>

<div class="container">

<nav class="navbar">
    <h1>Fashion Store</h1>
    <ul>
        <li><a href="index.jsp">Home</a></li>
        <li><a href="products">Products</a></li>
        <li><a href="cart.jsp">Cart</a></li>
      <%
    String user = (String) session.getAttribute("user");

    if(user != null){
%>

<li><a href="#">Welcome, <%= user %></a></li>
<li><a href="logout">Logout</a></li>

<%
    } else {
%>

<li><a href="login.jsp">Login</a></li>

<%
    }
%>
    </ul>
</nav>

<div class="cart-box">
    <h2>Your Cart</h2>

    <table>
        <tr>
            <th>Product</th>
            S<th>Image</th>
            <th>Price</th>
        </tr>

        <%
            List<Product> cart = (List<Product>) session.getAttribute("cart");
            double total = 0;

            if(cart != null && cart.size() > 0){
                for(Product p : cart){
                    total += p.getPrice();
        %>

        <tr>
            <td><%= p.getName() %></td>
            <td><img src="<%= p.getImage_url() %>" width="80"></td>
            <td>&#8377;<%= p.getPrice() %></td>
        </tr>

        <%
                }
            } else {
        %>

        <tr>
            <td colspan="3">Cart is empty</td>
        </tr>

        <%
            }
        %>

    </table>

    <h2>Total: &#8377;<%= total %></h2>

    <a href="checkout.jsp">
        <button class="checkout-btn">Checkout</button>
    </a>
</div>

</body>
</html>