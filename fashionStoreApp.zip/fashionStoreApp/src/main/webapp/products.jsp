<%@ page import="java.util.List" %>
<%@ page import="com.fashionstore.model.Product" %>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Products</title>

<link rel="stylesheet"
href="<%= request.getContextPath() %>/css/style.css">
</head>

<body>

<div class="container">

<nav class="navbar">
<h1>Fashion Store</h1>

<ul>
<li><a href="index.jsp">Home</a></li>
<li><a href="products">Products</a></li>
<li><a href="cart.jsp">Cart</a></li>
<li><a href="login.jsp">Login</a></li>
</ul>
</nav>

<section class="products">

<div class="product-header">
<h2>All Products</h2>

<form action="products" method="get">
<input type="text" name="search" placeholder="Search products...">
<button type="submit">Search</button>
</form>
</div>

<div class="product-container">

<%
List<Product> products =
(List<Product>) request.getAttribute("products");

if (products == null || products.isEmpty()) {
%>

<h3>No products found</h3>

<%
} else {

for(Product p : products){
%>

<div class="product-card">

<a href="product-details?id=<%= p.getId() %>">
<img src="<%= p.getImage_url() %>" alt="product">
</a>

<h3><%= p.getName() %></h3>

<p>&#8377;<%= p.getPrice() %></p>

<a href="product-details?id=<%= p.getId() %>">
<button type="button">View Details</button>
</a>

</div>

<%
}
}
%>

</div>

</section>

</div>

</body>
</html>