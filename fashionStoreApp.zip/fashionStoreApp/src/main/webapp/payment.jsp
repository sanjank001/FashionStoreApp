<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
        }

        .payment-box{
            width:450px;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .payment-box h2{
            text-align:center;
            margin-bottom:30px;
        }

        .payment-box input{
            width:100%;
            padding:12px;
            margin-bottom:20px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .payment-box button{
            width:100%;
            padding:14px;
            border:none;
            background:green;
            color:white;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;
        }

    </style>

</head>

<body>

<div class="payment-box">

    <h2>Payment Details</h2>

    <form>

        <input type="text" placeholder="Card Holder Name">

        <input type="text" placeholder="Card Number">

        <input type="text" placeholder="Expiry Date">

        <input type="password" placeholder="CVV">

        <button>Pay Now</button>

    </form>

</div>

</body>
</html>