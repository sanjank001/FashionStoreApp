<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            background:#f5f5f5;
        }

        .login-box{
            width:350px;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .login-box h2{
            text-align:center;
            margin-bottom:30px;
        }

        .login-box input{
            width:100%;
            padding:12px;
            margin-bottom:20px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .login-box button{
            width:100%;
            padding:12px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;
        }

    </style>

</head>

<body>

<div class="login-box">

    <h2>Login</h2>

   <form action="login" method="post">

       <input type="email" name="email" placeholder="Enter Email">

<input type="password" name="password" placeholder="Enter Password">

<button type="submit">Login</button>
    </form>

</div>

</body>
</html>