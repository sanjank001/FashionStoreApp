<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>About Us</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            background:#f5f5f5;
            padding:50px;
        }

        .about-box{
            width:80%;
            margin:auto;
            background:white;
            padding:50px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .about-box h1{
            margin-bottom:25px;
            color:blue;
        }

        .about-box p{
            line-height:1.8;
            font-size:18px;
            color:#444;
            margin-bottom:20px;
        }

    </style>

</head>

<body>

<div class="about-box">

    <h1>About Fashion Store</h1>

    <p>
        Fashion Store is a modern online shopping platform
        offering trendy fashion products for men and women.
        Our mission is to provide stylish and affordable clothing
        with the best shopping experience.
    </p>

    <p>
        We bring the latest collections, top-quality materials,
        and fast delivery to our customers.
    </p>

    <p>
        Thank you for choosing Fashion Store.
    </p>

</div>

</body>
</html>