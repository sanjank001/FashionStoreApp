<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial;
        }

        body{
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            background:#f5f5f5;
        }

        .register-box{
            width:380px;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 5px 15px rgba(0,0,0,0.1);
        }

        .register-box h2{
            text-align:center;
            margin-bottom:30px;
        }

        .register-box input{
            width:100%;
            padding:12px;
            margin-bottom:18px;
            border:1px solid #ccc;
            border-radius:10px;
        }

        .register-box button{
            width:100%;
            padding:12px;
            border:none;
            background:blue;
            color:white;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;
        }

        .register-box p{
            text-align:center;
            margin-top:15px;
        }

        .register-box a{
            color:blue;
            text-decoration:none;
        }
    </style>
</head>

<body>

<div class="register-box">

    <h2>Create Account</h2>

   <form action="register" method="post">
    <input type="text" name="name" placeholder="Enter Full Name">
<input type="email" name="email" placeholder="Enter Email">
<input type="password" name="password" placeholder="Enter Password">
       <button type="submit">Register</button>
   </form>

    <p>Already have an account? <a href="login.jsp">Login</a></p>

</div>

</body>
</html>