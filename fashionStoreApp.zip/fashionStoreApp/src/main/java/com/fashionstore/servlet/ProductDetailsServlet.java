package com.fashionstore.servlet;

import java.io.IOException;
import java.util.List;

import com.fashionstore.dao.ProductDAO;
import com.fashionstore.model.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/product-details")

public class ProductDetailsServlet
extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)

            throws ServletException, IOException {

        int id =
        Integer.parseInt(
        request.getParameter("id"));

        ProductDAO dao =
        new ProductDAO();

        List<Product> products =
        dao.getAllProducts();

        Product selected = null;

        for(Product p : products){

            if(p.getId() == id){

                selected = p;
                break;
            }
        }

        request.setAttribute(
        "product",
        selected);

        request.getRequestDispatcher(
        "product-details.jsp")
        .forward(request, response);
    }
}