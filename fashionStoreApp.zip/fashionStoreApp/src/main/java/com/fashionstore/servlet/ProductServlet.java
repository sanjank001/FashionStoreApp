package com.fashionstore.servlet;

import java.io.IOException;
import java.util.List;

import com.fashionstore.dao.ProductDAO;
import com.fashionstore.model.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/products")

public class ProductServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)

            throws ServletException, IOException {

        ProductDAO dao = new ProductDAO();

        String search =
                request.getParameter("search");

        List<Product> products;

        if(search != null && !search.isEmpty()){

            products =
                dao.searchProducts(search);

        } else {

            products =
                dao.getAllProducts();
        }
        System.out.println("PRODUCT COUNT = " + products.size());

        request.setAttribute("products", products);

        request.getRequestDispatcher("products.jsp")
               .forward(request, response);
    }
}